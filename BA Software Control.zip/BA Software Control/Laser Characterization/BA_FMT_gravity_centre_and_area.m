clear; clf reset; clc;close ALL

xspread = 57;
yspread = 57;
xdev = 106;
ydev = 106;
nx = 5;
ny = 5;
P1x=1; P1y= 1;
P2x=-1; P2y=1;
P3x=-1; P3y=-1;

incrementx= (P1x-P2x)/(nx-1);
incrementy= (P2y-P3y)/(ny-1);

startposx=P1x;
startposy=P1y;
pointnumber = 0;
I = imread('phantom_8.png');
BWsdil = imbinarize(I);

[rows, columns, v] = find(BWsdil);
C_region = [rows columns v]; 

dim_mat_ex = [256 256];
sum_img = zeros(dim_mat_ex(1),dim_mat_ex(2));
num = 1:25;
thre = 0.6;
mat_ex = zeros(dim_mat_ex(1),dim_mat_ex(2),length(num));

for i=1:ny
    for j=1:nx
        
        pointnumber = pointnumber+1;
        xpos = startposx-incrementx*(mod(i,2)*(j-1)+mod(i-1,2)*(nx-j));
        ypos = startposy-(i-1)*incrementy;
        
        img_location = [xpos; ypos; 1];
        img_location(1,1) = round(img_location(1,1)*xspread+xdev);
        img_location(2,1) = round(img_location(2,1)*yspread+ydev);
        grid = [img_location(2,1) img_location(1,1) 1]; %location of points in image (pixels)
        
        A(pointnumber,1) = img_location(1,1);
        A(pointnumber,2) = img_location(2,1);
    end
end

for i = 1:length(num)
    
    I = imread(strcat('laserp',num2str(i),'.png'));
    I = double(I);
    tmp_img_bw = (I>thre*max(I(:)));
    
    sum_img = sum_img + I;
    se = strel('disk',2);%default = 5
    tmp_img_bw = imclose(tmp_img_bw,se);
    tmp_img_bw = imopen(tmp_img_bw,se);
    J(i,1)=sum(tmp_img_bw(:))*(141.5/256)*(141.5/256);
    if sum(tmp_img_bw(:)) >0
        stat_img = regionprops(tmp_img_bw,'centroid');
        if isempty(stat_img.Centroid)
            position_laser(i,:) = NaN;
        else
            position_laser(i,:) = [stat_img.Centroid(1,1) stat_img.Centroid(1,2)];
        end
    else
        position_laser(i,:) = NaN;
    end
end

figure()
axis square
bla = sum_img;

% BWs = (bla>60000);
% se90 = strel('line', 3, 90);
% se0 = strel('line', 3, 0);
% BWsdil = imdilate(BWs, [se90 se0]);
% BWoutline = bwperim(BWsdil);
% SegoutR = bla;
% SegoutG = bla;
% SegoutB = bla;
% SegoutR(BWoutline) = 255;
% SegoutG(BWoutline) = 0;
% SegoutB(BWoutline) = 0;
% SegoutRGB = cat(3, SegoutR, SegoutG, SegoutB);
% for i = 1:256
%     for j = 1:256
%         if (SegoutRGB(i,j) == 1)
%             SegoutRGB(i,j) = NaN;
%         end
%     end
% end
imagesc(bla);
hold on
plot(A(:,1),A(:,2),'ro');
% hold on
% imagesc(SegoutRGB)
hold on
plot(position_laser(:,1),position_laser(:,2),'b+');
title('MEMS Input and Scanned Points');
xlabel('x-direction [mm]');
ylabel('y-direction [mm]');
legend('Input Points','Scanned Points');
colormap(gray);
hold off
figure,plot(num,J)
title('Change in Area of illumination points')
ylim([0 45])
xlim([1 25])
xlabel('Point Index')
ylabel('Area [mm^2]')
legend('Data')