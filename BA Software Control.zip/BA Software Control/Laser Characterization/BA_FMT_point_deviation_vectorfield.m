clear; clc; close ALL;

%%%-----------------------Start - Initialize Parameters-----------------------%%%
nx = 5;
ny = 5;
dim_mat_ex = [256 256];
sum_img = zeros(dim_mat_ex(1),dim_mat_ex(2));
num = 1:nx*ny;
thre = 0.6;
mat_ex = zeros(dim_mat_ex(1),dim_mat_ex(2),length(num));


xspread = 57;
yspread = 57;
xdev = 106;
ydev = 106;

pointnumber=0;

P1x=1; P1y= 1;
P2x=-1; P2y=1;
P3x=-1; P3y=-1;

incrementx= (P1x-P2x)/(nx-1);
incrementy= (P2y-P3y)/(ny-1);

startposx=P1x;
startposy=P1y;
%%%-----------------------End - Initialize Parameters-----------------------%%%

%%%-----------------------Start - Imagesegmentation-----------------------%%%
I = imread('phantom_8.png');
BWsdil = imbinarize(I);
hold on

[rows, columns, v] = find(BWsdil); %everywhere where an object is, is considered as a 1 (white)
C_region = [rows columns v]; %fill the coordinates where a 1 is into C_region
%%%-----------------------End - Imagesegmentation-----------------------%%%

%---------------One-time Calibration Start--------------------------------------%

%Find all corner position with MATLAB data cursor tool.
c_1_pixel_location = [169 11 1];  %[-1 -1]
c_2_pixel_location = [33 12 1]; %[1 -1]
c_3_pixel_location = [190 194 1]; %[-1 1]
c_4_pixel_location = [19 192 1]; %[1 1]
%Convex Quadrilateral Transformation Matrix:
T = [-1 -1 1 0 0 0 c_1_pixel_location(1,1) c_1_pixel_location(1,1);
    0 0 0 -1 -1 1 c_1_pixel_location(1,2) c_1_pixel_location(1,2);
    1 -1 1 0 0 0 -c_2_pixel_location(1,1) c_2_pixel_location(1,1);
    0 0 0 1 -1 1 -c_2_pixel_location(1,2) c_2_pixel_location(1,2);
    -1 1 1 0 0 0 c_3_pixel_location(1,1) -c_3_pixel_location(1,1);
    0 0 0 -1 1 1 c_3_pixel_location(1,2) -c_3_pixel_location(1,2);
    1 1 1 0 0 0 -c_4_pixel_location(1,1) -c_4_pixel_location(1,1);
    0 0 0 1 1 1 -c_4_pixel_location(1,2) -c_4_pixel_location(1,2)];

%Pixelpoints:
b = [c_1_pixel_location(1,1); c_1_pixel_location(1,2); c_2_pixel_location(1,1); c_2_pixel_location(1,2); c_3_pixel_location(1,1); c_3_pixel_location(1,2); c_4_pixel_location(1,1); c_4_pixel_location(1,2)];

%solve linear equation system:
X = linsolve(T,b);

transformation = [X(1,1) X(2,1) X(3,1); X(4,1) X(5,1) X(6,1); X(7,1) X(8,1) 1];
%this matrix transforms the pixels in the mirror-scanning field range into
%the range [-1 1].
%%%-----------------------End - One-time Calibration-------------------------%%%

for i=1:ny
    for j=1:nx
        
        pointnumber = pointnumber+1;
        xpos = startposx-incrementx*(mod(i,2)*(j-1)+mod(i-1,2)*(nx-j));
        ypos = startposy-(i-1)*incrementy;
        
        img_location = [xpos; ypos; 1]; %transform the grid into pixel grid
        %img_location = img_location/img_location(3,1);
        img_location(1,1) = round(img_location(1,1)*xspread+xdev);
        img_location(2,1) = round(img_location(2,1)*yspread+ydev);
        grid = [img_location(2,1) img_location(1,1) 1]; %location of points in image (pixels)
        
        if ismember(grid, C_region,'rows')==0 %if gridpoint is not on mouse, ignore this point
            img_location(1,1) = NaN;
            img_location(2,1) = NaN;
        end
        
        illumination_points_pixel = [img_location(1,1); img_location(2,1); 1];
        illumination_points_MEMS = (transformation\illumination_points_pixel);
        illumination_points_MEMS = illumination_points_MEMS/illumination_points_MEMS(3,1); %normalization
        if (illumination_points_MEMS(1,1)>1 || illumination_points_MEMS(2,1)>1 ||illumination_points_MEMS(1,1)<-1|| illumination_points_MEMS(2,1)<-1)
            illumination_points_MEMS = [NaN; NaN; 1];
        end
        %tell the mirror to which angle he has to turn
        
        %error probably here
        %if(isnan(illumination_points_MEMS(1,:)) && isnan(illumination_points_MEMS(2,:)))
        
        A(pointnumber,1) = img_location(1,1);
        A(pointnumber,2) = img_location(2,1);
    end
end

hold on
I = imresize(I,[141.5 141.5]);
imshow(imbinarize(I));
hold on;
plot(A(:,1).*(141.5/256),A(:,2).*(141.5/256),'ro');
hold on
for i = 1:length(num)
    
    I = mat_ex(:,:,(num(i)));
    I = imread(strcat('laserp',num2str(i),'.png'));
    I = double(I);
    %figure,imagesc(I);
    
    sum_img = sum_img + I;
    tmp_img_bw = (I>thre*max(I(:)));
    se = strel('disk',2);%default = 5
    tmp_img_bw = imclose(tmp_img_bw,se);
    tmp_img_bw = imopen(tmp_img_bw,se);
    
    if sum(tmp_img_bw(:)) >0
        stat_img = regionprops(tmp_img_bw,'centroid');
        if isempty(stat_img.Centroid)
            position_laser(i,:) = NaN;
        else
            position_laser(i,:) = [stat_img.Centroid(1,1) stat_img.Centroid(1,2)];
        end
    else
        position_laser(i,:) = NaN;
    end
end

plot(position_laser(:,1).*(141.5/256),position_laser(:,2).*(141.5/256),'b+');
hold on

alpha = 0.3;  % Size of arrow head relative to the length of the vector
beta = 0.3;  % Width of the base of the arrow head relative to the length

for i = 1:nx*ny
    p0(1) = position_laser(i,1);
    p0(2) = position_laser(i,2);
    p1(1) = A(i,1);
    p1(2) = A(i,2);
    
    plot([position_laser(i,1);A(i,1)].*(141.5/256),[position_laser(i,2);A(i,2)].*(141.5/256),'color','[0,0.7,0.9]');   % Draw a line between p0 and p1
    hold on
    
    p = p1-p0;
    hu = [A(i,1)-alpha*(p(1)+beta*(p(2)+eps)); A(i,1); A(i,1)-alpha*(p(1)-beta*(p(2)+eps))];
    hv = [A(i,2)-alpha*(p(2)-beta*(p(1)+eps)); A(i,2); A(i,2)-alpha*(p(2)+beta*(p(1)+eps))];
    
    plot(hu(:).*(141.5/256),hv(:).*(141.5/256),'color','[0,0.7,0.9]')  % Plot arrow head
    hold on
end
axis on
set(gca,'LooseInset',get(gca,'TightInset'));
title('MEMS Error Field with calculated Gravity Centres');
xlabel('x-direction [mm]');
ylabel('y-direction [mm]');
legend('Input Points','Scanned Points','Deviation');
hold off