close all;clc;clear;

data = importdata('table_power_measure.txt');
Measurement = data(:,1);
data2 = data(:,2);
eff = 100*(data2./Measurement);

figure()
plot(Measurement,data2,'x');
title('Power Measurement after Optical Fibre');
xlabel('Controlled Power Input [mW]');
ylabel('Measured Power Output [mW]');
legend('Measurement')

figure()
plot(Measurement,eff,'x');
title('Efficiency of the Optical Fibre');
xlabel('Controlled Power Input [mW]');
ylabel('Efficiency [%]');