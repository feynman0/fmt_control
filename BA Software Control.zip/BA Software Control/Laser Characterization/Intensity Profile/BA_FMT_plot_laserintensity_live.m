close all;clc;clear;

conv = 141.5/2048;
range = 1:2048;
range = range*conv;

exposure_time=3; %Choose Exposure Time

triggermode=0;
glvar=struct('do_libunload',0,'do_close',0,'camera_open',0,'out_ptr',[]);
if(~exist('triggermode','var'))
    triggermode = 0;
end
[err,glvar]=pco_camera_open_close(glvar);
pco_errdisp('pco_camera_setup',err);
disp(['camera_open should be 1 is ',int2str(glvar.camera_open)]);
if(err~=0)
    commandwindow;
    return;
end
out_ptr=glvar.out_ptr;
subfunc=pco_camera_subfunction();
subfunc.fh_stop_camera(out_ptr);
subfunc.fh_reset_settings_to_default(out_ptr);
subfunc.fh_enable_timestamp(out_ptr,2);
subfunc.fh_set_exposure_times(out_ptr,exposure_time,2,0,2)
subfunc.fh_set_triggermode(out_ptr,triggermode);
errorCode = calllib('PCO_CAM_SDK', 'PCO_ArmCamera', out_ptr);
pco_errdisp('PCO_ArmCamera',errorCode);
subfunc.fh_set_transferparameter(out_ptr);
subfunc.fh_get_triggermode(out_ptr);
subfunc.fh_show_frametime(out_ptr);

%%Take Image
disp('Camera Takes Image');
[err,ima,glvar]=pco_camera_stack(1,glvar);
if(err==0)
    m=max(max(ima(10:end-10,10:end-10)));
    draw_image(ima,[0 m+100]);
    close()
end
set(gca,'LooseInset',get(gca,'TightInset'));
%%Close Camera
subfunc.fh_stop_camera(out_ptr);
if(glvar.camera_open==1)
    glvar.do_close=1;
    glvar.do_libunload=1;
    pco_camera_open_close(glvar);
end
clear glvar;
commandwindow;
im1 = ima;
clear ima;

disp('10s to switch of laser');
pause(10);

glvar=struct('do_libunload',0,'do_close',0,'camera_open',0,'out_ptr',[]);
if(~exist('triggermode','var'))
    triggermode = 0;
end
[err,glvar]=pco_camera_open_close(glvar);
pco_errdisp('pco_camera_setup',err);
disp(['camera_open should be 1 is ',int2str(glvar.camera_open)]);
if(err~=0)
    commandwindow;
    return;
end
out_ptr=glvar.out_ptr;
subfunc=pco_camera_subfunction();
subfunc.fh_stop_camera(out_ptr);
subfunc.fh_reset_settings_to_default(out_ptr);
subfunc.fh_enable_timestamp(out_ptr,2);
subfunc.fh_set_exposure_times(out_ptr,exposure_time,2,0,2)
subfunc.fh_set_triggermode(out_ptr,triggermode);
errorCode = calllib('PCO_CAM_SDK', 'PCO_ArmCamera', out_ptr);
pco_errdisp('PCO_ArmCamera',errorCode);
subfunc.fh_set_transferparameter(out_ptr);
subfunc.fh_get_triggermode(out_ptr);
subfunc.fh_show_frametime(out_ptr);

%%Take Image
disp('Camera Takes Image');
[err,ima,glvar]=pco_camera_stack(1,glvar);
if(err==0)
    m=max(max(ima(10:end-10,10:end-10)));
    draw_image(ima,[0 m+100]);
    close()
end
%%Close Camera
subfunc.fh_stop_camera(out_ptr);
if(glvar.camera_open==1)
    glvar.do_close=1;
    glvar.do_libunload=1;
    pco_camera_open_close(glvar);
end
clear glvar;
commandwindow;
im2 = ima;
clear ima;
im2(im2 > 65534) = 0;%remove camera time text overlay
im1(im1 > 65534) = 0;%remove camera time text overlay
disp('removed');
%2D with noise
figure,subplot(2,2,1),imagesc(range,range,im1)
title('2D Intensity Profile with noise')
axis image
xlabel('x [mm]')
ylabel('y [mm]')

%2D without noise
subplot(2,2,2),imagesc(range,range,im1-im2)
title('2D Intensity Profile without noise')
axis image
xlabel('x [mm]')
ylabel('y [mm]')

%3D with noise
subplot(2,2,3),mesh(range,range,im1)
title('3D Intensity Profile with noise')
colormap(hot)
colorbar
xlabel('x [mm]')
ylabel('y [mm]')
zlabel('Intensity [-]')


%3D without noise
subplot(2,2,4),mesh(range,range,im1-im2)
title('3D Intensity Profile without noise')
colormap(hot)
colorbar
xlabel('x [mm]')
ylabel('y [mm]')
zlabel('Intensity [-]')
