close all; clc; clear;

iter = 1; %if changed to >1, change num2str argument in plot to fwhm1_fit(1,1)
fwhm1_rawX = zeros(iter,1);
fwhm1_fitX = zeros(iter,1);
fwhm1_rawY = zeros(iter,1);
fwhm1_fitY = zeros(iter,1);

dy = 141.5/2048; %mm/px
y = 1:2048;
dx = 141.5/2048; %mm/px
x = 1:2048;

%0 0
locx = 629;
locy = 817;
%-1 1
locx1 = 1514;
locy1 = 1520;
%-1 -1
locx2 = 69;
locy2 = 1412;
%change for chosen point
%locx = locx2;
%locy = locy2;

for i =1:iter
    %%-----------------------Start - Initialize Camera/MEMS-----------------------%%%
    mMTIDevice = MTIDevice;
    
    disp('Connecting...');
    
    availableDevices = mMTIDevice.GetAvailableDevices();
    if (availableDevices.NumDevices < 1)
        disp('Unsuccessful!');
        return;
    end
    
    close()
    
    mMTIDevice.ListAvailableDevices(availableDevices);
    comport = 'COM5';
    mMTIDevice.ConnectDevice(comport);
    
    disp('Connected to MEMS');
    
    if (mMTIDevice.GetLastError() ~= MTIError.MTI_SUCCESS)
        mMTIDevice.DisconnectDevice();
        delete(mMTIDevice);
        return;
    end
    
    exposure_time=3; %Choose Exposure Time
    
    triggermode=0;
    glvar=struct('do_libunload',0,'do_close',0,'camera_open',0,'out_ptr',[]);
    if(~exist('triggermode','var'))
        triggermode = 0;
    end
    [err,glvar]=pco_camera_open_close(glvar);
    pco_errdisp('pco_camera_setup',err);
    disp(['camera_open should be 1 is ',int2str(glvar.camera_open)]);
    if(err~=0)
        commandwindow;
        return;
    end
    out_ptr=glvar.out_ptr;
    subfunc=pco_camera_subfunction();
    subfunc.fh_stop_camera(out_ptr);
    subfunc.fh_reset_settings_to_default(out_ptr);
    subfunc.fh_enable_timestamp(out_ptr,2);
    subfunc.fh_set_exposure_times(out_ptr,exposure_time,2,0,2)
    subfunc.fh_set_triggermode(out_ptr,triggermode);
    errorCode = calllib('PCO_CAM_SDK', 'PCO_ArmCamera', out_ptr);
    pco_errdisp('PCO_ArmCamera',errorCode);
    subfunc.fh_set_transferparameter(out_ptr);
    subfunc.fh_get_triggermode(out_ptr);
    subfunc.fh_show_frametime(out_ptr);
    
    mMTIDevice.ResetDevicePosition();
    
    lParams = mMTIDevice.LoadDeviceParams('mtidevice.ini');
    mMTIDevice.SetDeviceParams(lParams);
    mMTIDevice.SetDeviceParam( MTIParam.DataScale, 1.0);
    mMTIDevice.SetDeviceParam( MTIParam.SampleRate, 20000);
    err = mMTIDevice.GetLastError();
    mMTIDevice.SetDeviceParam( MTIParam.MEMSDriverEnable, 1)
    %%%-----------------------End - Initialize Camera/MEMS-----------------------%%%
    
    mMTIDevice.GoToDevicePosition(0,0,255,10); %Choose point to scan
    
    %%Take Image
    disp('Camera Takes Image');
    [err,ima,glvar]=pco_camera_stack(1,glvar);
    if(err==0)
        m=max(max(ima(10:end-10,10:end-10)));
        draw_image(ima,[0 m+100]);
        close()
    end
    set(gca,'LooseInset',get(gca,'TightInset'));
    %%Close Camera
    subfunc.fh_stop_camera(out_ptr);
    if(glvar.camera_open==1)
        glvar.do_close=1;
        glvar.do_libunload=1;
        pco_camera_open_close(glvar);
    end
    clear glvar;
    commandwindow;
    im1 = ima;
    clear ima;
    
    mMTIDevice.ResetDevicePosition();
    mMTIDevice.SetDeviceParam( MTIParam.MEMSDriverEnable, 0 );
    mMTIDevice.DisconnectDevice();
    delete(mMTIDevice);
    %%%---------------------------------------------------------------------%%%
    
    %2D x view FWHM - GAUSS
    x = x*dx;
    
    % Raw data
    % Find the half max value.
    halfMax_rawX = (min(im1(locx,:)) + max(im1(locx,:))) / 2;
    % Find where the data first drops below half the max.
    index1_rawX = find(im1(locx,:) >= halfMax_rawX, 1, 'first');
    % Find where the data last rises above half the max.
    index2_rawX = find(im1(locx,:) >= halfMax_rawX, 1, 'last');
    % FWHM in indexes.
    fwhm_rawX = index2_rawX-index1_rawX + 1;
    fwhm_rawX = fwhm_rawX * dx;
    maxim_rawX = [halfMax_rawX, halfMax_rawX];
    
    % Gauss fit
    f1 = fit(x.',(double(im1(locx,:))).','gauss1');
    f2_Y = f1(x);
    halfMax_fitX = (min(f2_Y) + max(f2_Y)) / 2;
    index1_fitX = find(f2_Y >= halfMax_fitX, 1, 'first');
    index2_fitX = find(f2_Y >= halfMax_fitX, 1, 'last');
    fwhm_fitX = index2_fitX-index1_fitX + 1;
    fwhm_fitX = fwhm_fitX * dx;
    
    fwhm1_rawX(i) =fwhm_rawX;
    fwhm1_fitX(i) =fwhm_fitX;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %2D y view FWHM - GAUSS
    y = y*dy;
    
    % Raw data
    halfMax_rawY = (min(im1(:,locy)) + max(im1(:,locy))) / 2;
    index1_rawY = find(im1(:,locy) >= halfMax_rawY, 1, 'first');
    index2_rawY = find(im1(:,locy) >= halfMax_rawY, 1, 'last');
    fwhm_rawY = index2_rawY-index1_rawY + 1;
    fwhm_rawY = fwhm_rawY * dy;
    maxim_rawY = [halfMax_rawY, halfMax_rawY];
    
    % Gauss fit
    f2 = fit(y.',double((im1(:,locy))),'gauss1');
    f2_Y = f2(y);
    halfMax_fitY = (min(f2_Y) + max(f2_Y)) / 2;
    index1_fitY = find(f2_Y >= halfMax_fitY, 1, 'first');
    index2_fitY = find(f2_Y >= halfMax_fitY, 1, 'last');
    fwhm_fitY = index2_fitY-index1_fitY + 1;
    fwhm_fitY = fwhm_fitY * dy;
    
    fwhm1_rawY(i) =fwhm_rawY;
    fwhm1_fitY(i) =fwhm_fitY;
    
end

%     figure,plot(fwhm1_rawX);
%     figure,plot(fwhm1_fitX);
%     figure,plot(fwhm1_rawY);
%     figure,plot(fwhm1_fitY);

figure()
subplot(1,2,1),plot([0,2048*dx],maxim_rawX,'g')
hold on
plot(f1,x,(im1(locx,:)),'b-')
xlim([40 80]) %choose range determine by first looking at [0 2048*dx]
title('Intensity profile at point [0 0] in x') %change title points
xlabel('x-direction [mm]')
ylabel('Intensity [-]')
legend(['Half Maximum = ' num2str(fwhm1_fitX)],'Data','Gaussian Fit')
hold off
subplot(1,2,2),plot([0,2048*dy],maxim_rawY,'g')
hold on
plot(f2,y,(im1(:,locy)),'b-')
xlim([20 60]) %choose range 
title('Intensity profile at point [0 0] in y')%change title points
xlabel('y-direction [mm]')
ylabel('Intensity [-]')
legend(['Half Maximum = ' num2str(fwhm1_fitY)],'Data','Gaussian Fit')
hold off