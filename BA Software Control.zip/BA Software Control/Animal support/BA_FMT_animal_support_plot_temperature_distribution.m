close();clc;clear;
figure()
data = importdata('temps.txt');
data1 = data(:,1);
time = 1:size(data1);
plot_data1 = plot(time,data1,'.');
x = 1:size(time);
xlim([0 300]);
ylim([20 60]);
hold on
plot(time,38.45*(1-exp(-0.02391*time)));
title('Temperature Increase of Heating Pad over Time');
xlabel('Time [s]');
ylabel('Degrees [�C]');
legend('Measured Data','Function Fit')
