clc;clear;

im1 = rgb2gray(imread('white_square.png'));
im2 = rgb2gray(imread('noise.png'));

muA = mean2(im1);
muB = mean2(im2);

sig = std2(im2);
sig2 = std2(im1);

cnr = abs(muA - muB)/sig;
snr = muA/sig;