%%%%MEMS-CONTROLL%%%%
clear; clf reset; clc;close ALL
%%%-----------------------Start - Initialize Mirror-----------------------%%%
mMTIDevice = MTIDevice;

disp('1');

availableDevices = mMTIDevice.GetAvailableDevices()
if (availableDevices.NumDevices < 1)
    disp('2'); 
    return;
end;
disp('3');
close()
mMTIDevice.ListAvailableDevices(availableDevices)

comport = 'COM5'; 
mMTIDevice.ConnectDevice(comport);

disp('4');

if (mMTIDevice.GetLastError() ~= MTIError.MTI_SUCCESS)
    mMTIDevice.DisconnectDevice();
    delete(mMTIDevice);
    return;
end
disp('5');

%mMTIDevice.ResetDevicePosition();
lParams = mMTIDevice.LoadDeviceParams('mtidevice.ini');
mMTIDevice.SetDeviceParams(lParams);
mMTIDevice.SetDeviceParam( MTIParam.DataScale, 1.0 );
mMTIDevice.SetDeviceParam( MTIParam.SampleRate, 20000 );
err = mMTIDevice.GetLastError();
disp('6');
mMTIDevice.SetDeviceParam( MTIParam.MEMSDriverEnable, 1 );
mMTIDevice.ResetDevicePosition();
disp('7');
mMTIDevice.SetDeviceParam( MTIParam.MEMSDriverEnable, 0 );%After the device is back to origin - disable the amplifier
disp('8');

mMTIDevice.DisconnectDevice();
delete(mMTIDevice);
disp('Closed successfully.');