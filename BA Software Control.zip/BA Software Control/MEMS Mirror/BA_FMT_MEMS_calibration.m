clear; clc; close ALL;
%%%-----------------------Start - Initialize Mirror-----------------------%%%

path(path,'./MTIDeviceMatlab');
clear; clf reset; clc;
mMTIDevice = MTIDevice;
disp('Connecting...');
availableDevices = mMTIDevice.GetAvailableDevices();

if (availableDevices.NumDevices < 1)
    disp('Connection Failed!');
    return;
end
mMTIDevice.ListAvailableDevices(availableDevices);
comport = 'COM5';
mMTIDevice.ConnectDevice(comport);
disp('Connection established.');
close()

if (mMTIDevice.GetLastError() ~= MTIError.MTI_SUCCESS)
    mMTIDevice.DisconnectDevice();
    delete(mMTIDevice);
    return;
end

mMTIDevice.ResetDevicePosition();
lParams = mMTIDevice.LoadDeviceParams('mtidevice.ini');
mMTIDevice.SetDeviceParams(lParams);
mMTIDevice.SetDeviceParam( MTIParam.DataScale, 1.0 );
mMTIDevice.SetDeviceParam( MTIParam.SampleRate, 200 );
err = mMTIDevice.GetLastError();
mMTIDevice.SetDeviceParam( MTIParam.MEMSDriverEnable, 1 )
%%-----------------------End - Initialize Mirror-----------------------%%%

%%-----------------------Start - Initialize Camera-----------------------%%%

exposure_time=200;
triggermode=0;
glvar=struct('do_libunload',0,'do_close',0,'camera_open',0,'out_ptr',[]);

if(~exist('triggermode','var'))
    triggermode = 0;
end
reduce_display_size=1;

[err,glvar]=pco_camera_open_close(glvar);
pco_errdisp('pco_camera_setup',err);
disp(['camera_open should be 1 is ',int2str(glvar.camera_open)]);
if(err~=0)
    commandwindow;
    return;
end

out_ptr=glvar.out_ptr;
subfunc=pco_camera_subfunction();
subfunc.fh_stop_camera(out_ptr);
subfunc.fh_reset_settings_to_default(out_ptr);
subfunc.fh_enable_timestamp(out_ptr,2);
subfunc.fh_set_exposure_times(out_ptr,exposure_time,2,0,2)
subfunc.fh_set_triggermode(out_ptr,triggermode);
errorCode = calllib('PCO_CAM_SDK', 'PCO_ArmCamera', out_ptr);
pco_errdisp('PCO_ArmCamera',errorCode);
subfunc.fh_set_transferparameter(out_ptr);
subfunc.fh_get_triggermode(out_ptr);
subfunc.fh_show_frametime(out_ptr);

%%%-----------------------End - Initialize Camera-----------------------%%%
calib_points = [-1 -1;-1 1;1 -1;1 1];

disp('Start Measurement.');
for i = 1:4
    mMTIDevice.GoToDevicePosition(calib_points(i,1),calib_points(i,2),255,10); %go to new position in 10ms
    
    disp(strcat('Take image of cornerpoint: ',num2str(i)));
    [err,ima,glvar]=pco_camera_stack(1,glvar);
    if(err==0)
        m=max(max(ima(10:end-10,10:end-10)));
        draw_image(ima,[0 m+100]);
        close()
    end
    ima = imresize(ima,[256 256]);
    im(:,:,i)=ima;
    clear ima;
    set(gca,'LooseInset',get(gca,'TightInset'));
    imwrite(im(:,:,i),strcat('C:\Users\Andrin\Documents\MATLAB\Images\calib',num2str(i),'.png'));
end
disp('Measurement done.');

close()
mMTIDevice.ResetDevicePosition();
mMTIDevice.SetDeviceParam( MTIParam.MEMSDriverEnable, 0 );
mMTIDevice.DisconnectDevice();
delete(mMTIDevice);
disp('MEMS closed successfully..');

subfunc.fh_stop_camera(out_ptr);
if(glvar.camera_open==1)
    glvar.do_close=1;
    glvar.do_libunload=1;
    pco_camera_open_close(glvar);
end
clear glvar;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Calculating cornerpoints');
dim_mat_ex = [256 256];
sum_img = zeros(dim_mat_ex(1),dim_mat_ex(2));
num = 1:4;
thre = 0.6;
mat_ex = zeros(dim_mat_ex(1),dim_mat_ex(2),length(num));

for i = 1:length(num)
    
    I = mat_ex(:,:,(num(i)));
    I = imread(strcat('calib',num2str(i),'.png'));
    I = double(I);
    sum_img = sum_img + I;
    tmp_img_bw = (I>thre*max(I(:)));
    se = strel('disk',2);%default = 5
    tmp_img_bw = imclose(tmp_img_bw,se);
    tmp_img_bw = imopen(tmp_img_bw,se);
    
    if sum(tmp_img_bw(:)) >0
        stat_img = regionprops(tmp_img_bw,'centroid');
        if isempty(stat_img.Centroid)
            position_laser(i,:) = NaN;
        else
            position_laser(i,:) = stat_img.Centroid;
        end
    else
        position_laser(i,:) = NaN;
    end
end

figure,imagesc(sum_img);
hold on
plot(position_laser(:,1),position_laser(:,2),'r+');
hold off
colormap(gray);

c_1_pixel_location = [position_laser(1,1) position_laser(1,2) 1]  %[-1 -1]
c_2_pixel_location = [position_laser(2,1) position_laser(2,2) 1] %[1 -1]
c_3_pixel_location = [position_laser(3,1) position_laser(3,2) 1] %[-1 1]
c_4_pixel_location = [position_laser(4,1) position_laser(4,2) 1] %[1 1]