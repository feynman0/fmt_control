%%%%MEMS-Find Corners%%%%
clear; clf reset; clc;

mMTIDevice = MTIDevice;

disp('Connecting...');


availableDevices = mMTIDevice.GetAvailableDevices();
if (availableDevices.NumDevices < 1)
    disp('Unsuccessful!'); 
    return;
end

close()

mMTIDevice.ListAvailableDevices(availableDevices);
comport = 'COM5'; 
mMTIDevice.ConnectDevice(comport);

disp('Connected to MEMS');

if (mMTIDevice.GetLastError() ~= MTIError.MTI_SUCCESS)
    mMTIDevice.DisconnectDevice();
    delete(mMTIDevice);
    return;
end

mMTIDevice.ResetDevicePosition();	% optional, send mirror to origin and zero offsets

lParams = mMTIDevice.LoadDeviceParams('mtidevice.ini');
mMTIDevice.SetDeviceParams(lParams);
mMTIDevice.SetDeviceParam( MTIParam.DataScale, 1.0);
mMTIDevice.SetDeviceParam( MTIParam.SampleRate, 20000);
err = mMTIDevice.GetLastError();
mMTIDevice.SetDeviceParam( MTIParam.MEMSDriverEnable, 1)

disp('Start Measurement.');
num = 0;
while(num<30)
    num = num + 1;
    mMTIDevice.GoToDevicePosition(-1,-1,255,10); %go to new position in 10ms
    disp('-1 -1');
    pause(1);   %wait 6 seconds to mark position
    mMTIDevice.GoToDevicePosition(-1,1,255,10); %go to new position in 10ms
    disp('-1 1');
    pause(1);   %wait 6 seconds to mark position
    mMTIDevice.GoToDevicePosition(1,-1,255,10); %go to new position in 10ms
    disp('1 -1');
    pause(1);   %wait 6 seconds to mark position
    mMTIDevice.GoToDevicePosition(1,1,255,10); %go to new position in 10ms
    disp('1 1');
    pause(1);   %wait 6 seconds to mark position
    if (num == 15)
        prompt = 'Again? [y/x]';
        str = input(prompt,'s');
        if isempty(str)
            str = 'y';
        end
        if str == 'x'
            break;
        end
    end
end

disp('Measurement done.');
mMTIDevice.ResetDevicePosition();
mMTIDevice.SetDeviceParam( MTIParam.MEMSDriverEnable, 0 );
mMTIDevice.DisconnectDevice();
delete(mMTIDevice);

disp('Closed successfully.');