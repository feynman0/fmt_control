classdef MTIParam
    enumeration
		HardwareFilterOn,			% read only
		VmaxMEMSDriver,				% read only
		DeviceState,				% read only
		DeviceErrorRegister,		% read only
		USARTBaudRate,
		SampleRate,
		HardwareFilterBw,
		VdifferenceMax,
		Vbias,
		OutputOffsets,
		DataScale,
		MEMSDriverEnable,
		DigitalOutputEnable,
		BufferOffset,
		DeviceAxes,
		BootSetting,
		DataMode,
		SyncMode,
		FramesPerSecond,
		InterpolationType,
		WaveformType,
    end
end