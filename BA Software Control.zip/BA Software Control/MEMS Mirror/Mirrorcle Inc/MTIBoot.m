classdef MTIBoot < double
    enumeration
    	Boot_With_Factory_Defaults (0),
    	Boot_With_Flash_Device_Params (1),
    	Boot_With_Flash_Data_And_Autorun (2),
    	Boot_With_Flash_Data_No_Autorun (3),
    end
end
