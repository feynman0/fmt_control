classdef MTIFlash < double
    enumeration
    	Device_Params (0),
    	Data_In_Buffer (1),
    end
end
