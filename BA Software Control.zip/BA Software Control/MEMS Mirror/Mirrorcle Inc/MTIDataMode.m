classdef MTIDataMode < double
    enumeration
  	Sample_Output (0),
  	Sample_And_Analog_Input_Buffer (1),
  	Keypoint (2),
  	Text (3),
  	Waveform (4),
  	Analog_Input_To_Output (5),
  	Sample_And_Analog_Input_Stream (6),
  	Sample_And_Analog_Input_Track (7),
  	Auto_Track (8),
    end
end
