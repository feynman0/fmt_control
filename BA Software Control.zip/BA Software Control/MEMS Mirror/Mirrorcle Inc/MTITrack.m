classdef MTITrack < double
    enumeration
    	Threshold (0),
    	NormalGain (1),
    	TangentialGain (2),
    	BufferDelay (3),
    	HitRatio (4),
    	EnableSearch (5),
    	EnableOffsetStreaming (6),
    	EnableTrack (7),
    	SamplesAveraged (8),
    end
end
