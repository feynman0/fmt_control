classdef MTIDeviceLimits
    properties
    	SampleRate_Min,						% read only
    	SampleRate_Max,						% read only
    	SamplesPerFrame_Min,				% read only
    	SamplesPerFrame_Max,				% read only
    	HardwareFilterBw_Min,				% read only
    	HardwareFilterBw_Max,				% read only
    	FramesPerSecond_Min,				% read only
    	FramesPerSecond_Max,				% read only
    	VdifferenceMax_Min,					% read only
    	VdifferenceMax_Max,					% read only
    	Vbias_Min,							% read only
    	Vbias_Max,							% read only
    end
end
