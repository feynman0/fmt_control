classdef MTIAxes < double
    enumeration
	Normal (0),
	FlipXY (1),
	MirrorY (2),
	MirrorY_FlipXY (3),
	MirrorX (4),
	MirrorX_FlipXY (5),
	MirrorX_MirrorY (6),
	MirrorX_MirrorY_FlipXY (7),  
    end
end