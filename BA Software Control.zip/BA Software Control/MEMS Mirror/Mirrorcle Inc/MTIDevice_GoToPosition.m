%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Created by Ken Castelino, Veljko Milanovic, Abhishek Kasturi
% Mirrorcle Technologies, Inc. 2011-2015
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compatible with Firmware 2.1.10.1.x or newer
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MTIDevice_GoToPosition demonstrates the use of the GoToDevicePosition function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
path(path,'./MTIDeviceMatlab');
clear; clf reset; clc;
% Create an object of the MTIDevice class to access its functions,
% variables, and the target device at serial port
mMTIDevice = MTIDevice;

% exposure_time=100;
% triggermode=0;
% glvar=struct('do_libunload',0,'do_close',0,'camera_open',05,'out_ptr',[]);


try
availableDevices = mMTIDevice.GetAvailableDevices();
if (availableDevices.NumDevices < 1) return; end;
mMTIDevice.ListAvailableDevices(availableDevices);
% if the user knows the comport can proceed this way
comport = 'COM3'; % serial com port where SiLabs UART device is connected
% if the user does not know the port or has multiple devices attached
%id = input('Please choose a Target Device ID: ');
comport = cell2mat(availableDevices.CommPortName(1));   % choose the first Controller found
mMTIDevice.ConnectDevice(comport);

if (mMTIDevice.GetLastError() ~= MTIError.MTI_SUCCESS)
    mMTIDevice.DisconnectDevice();
    delete(mMTIDevice);
    return;
end

mMTIDevice.ResetDevicePosition();	% optional, send mirror to origin and zero offsets

% apply new device parameters as desired by user at beginning of the session
% it is recommended to load the manufacturer-provided ini file for a
% specific device and set those parameters
lParams = mMTIDevice.LoadDeviceParams('mtidevice.ini');
mMTIDevice.SetDeviceParams(lParams);

% any additional parameters can be set directly as follows:
mMTIDevice.SetDeviceParam( MTIParam.DataScale, 1.0 );
mMTIDevice.SetDeviceParam( MTIParam.SampleRate, 20000 );
err = mMTIDevice.GetLastError();
% turn MEMS driver on
mMTIDevice.SetDeviceParam( MTIParam.MEMSDriverEnable, 1 )

answer=0;
display(' ');
display('Input position the device should step and settle to.');
display('Use normalized positions from 0 to 1 for 1-Quadrant devices.');
display('Use normalized positions from -1 to 1 for 4-Quadrant devices.');
display('Program will exit when you enter a value outside those limits\n');
display(' ');
while answer<=1
    s=input('Input go to position in xpos,ypos format: ','s');
    Pos = sscanf(s, '%f , %f');
    xpos = Pos(1,1);
    ypos = Pos(2,1);
    answer=max(abs(xpos),abs(ypos));
    if answer<=1
        mMTIDevice.GoToDevicePosition(xpos,ypos,255,10); %go to new position in 10ms
    end
end


mMTIDevice.ResetDevicePosition();
%After the device is back to origin - disable the amplifier
mMTIDevice.SetDeviceParam( MTIParam.MEMSDriverEnable, 0 );
%res = ClearInputBuffer(mti); %optional command to clear any remaining bytes in serial port input buffer
mMTIDevice.DisconnectDevice();
delete(mMTIDevice);
display('Closed successfully..');

catch
    display('Unable to stop AO');
    mMTIDevice.ClearInputBuffer();
    mMTIDevice.DisconnectDevice();
    fclose(mMTIDevice.ao);
    delete(mMTIDevice.ao);
    delete(mMTIDevice);
    display('Closed in final catch..');
end;