classdef MTITrackParams
    properties
	Success;								%read only
	Threshold;
	NormalGain;
	TangentialGain;
	BufferDelay;
	HitRatio;
	EnableSearch;
	EnableOffsetStreaming;
	EnableTrack;
	SamplesAveraged;
    end
end
