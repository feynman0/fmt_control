clc; clear;

%initialization
alpha = 1:44; %mirror angle
beta = 7.116;
h = 140:250; %mirror position height
xfov_max_point = zeros(length(h),length(alpha));
xfov_min_point = zeros(length(h),length(alpha));
yfov_min_length = zeros(length(h),length(alpha));
yfov_max_length = zeros(length(h),length(alpha));
hypo_min = zeros(length(h),length(alpha));
hypo_max = zeros(length(h),length(alpha));
%calculate Maximum range value and minimum range value varying height h and mirror angle delta:

for i = 1:length(h)
    for j = 1:length(alpha)
        
        xfov_max_point(i,j) = h(i)*(tan(2*alpha(j)*pi/180+2*7.0669*pi/180));
        xfov_min_point(i,j) = h(i)*(tan(2*alpha(j)*pi/180-2*7.0669*pi/180));
        hypo_min(i,j) = h(i)./cos(2*(alpha(j)-7.0669)*pi/180);
        hypo_max(i,j) = h(i)./cos(2*(alpha(j)+7.0669)*pi/180);

    end
end

xfov=xfov_max_point-xfov_min_point; %FOV's in mm in x-direction

%calculate the FOV in y-direction

for i = 1:length(h)
    for j = 1:length(alpha)
        
        yfov_min_length(i,j)=2*hypo_min(i,j)*tan(2*beta*pi/180);
        yfov_max_length(i,j)=2*hypo_max(i,j)*tan(2*beta*pi/180);
        
    end
end
% Condition for optimal FOV-combination

inum=0;%counter
for k = 1:length(h)
    for l = 1:length(alpha)
        if (xfov(k,l)>70  && xfov_max_point(k,l)<=150 && xfov_min_point(k,l)>=40 )
            
           inum=inum+1;
           
           a(inum,1)=h(k); %corresponding heights
           a(inum,2)=alpha(l); %corresponding angles
           a(inum,3)=round(xfov_min_point(k,l)); %minimal value of FOV in y
           a(inum,4)=round(xfov_max_point(k,l)); %maximal value of FOV
           a(inum,5)=round(xfov(k,l)); %allowed FOV y-dir
           a(inum,6)=round((yfov_min_length(k,l))); %minimal allowed FOV in x
           a(inum,7)=round((yfov_max_length(k,l))); %maximal allowed FOV in x
        end
    end
end
latex_table = latex(sym(a))