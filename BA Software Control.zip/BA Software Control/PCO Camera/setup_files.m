%script: copy correct dll-files and compile grabfunc

 pco_camera_create_deffile();


 if verLessThan('matlab','8.0.0')
  copyfile('./x64/pco_uint32.m7','./pco_uint32.m');
  copyfile('./x64/pco_uint32err.m7','./pco_uint32err.m');
 else  
  copyfile('./x64/pco_uint32.m8','./pco_uint32.m');
  copyfile('./x64/pco_uint32err.m8','./pco_uint32err.m');
 end 

 if(strcmp(computer('arch'),'win32'))

  if(~exist('./sc2_cam.dll','file'))
   copyfile('./win32/sc2_cam.dll','./');
  end 
  if(exist('grabfunc.c','file'))
   if(~exist('./sc2_cam.lib','file'))
    copyfile('./win32/sc2_cam.lib','./');
   end 
  end
  if(~exist('./sc2_cl_me4.dll','file'))
   if(exist('./win32/sc2_cl_me4.dll','file'))
    copyfile('./win32/sc2_cl_me4.dll','./');
   end 
  end 
  if(~exist('./sc2_cl_nat.dll','file'))
   if(exist('./win32/sc2_cl_nat.dll','file'))
    copyfile('./win32/sc2_cl_nat.dll','./');
   end 
  end 
  if(~exist('./sc2_cl_mtx.dll','file'))
   if(exist('./win32/sc2_cl_mtx.dll','file'))
    copyfile('./win32/sc2_cl_mtx.dll','./');
   end 
  end 

 elseif(strcmp(computer('arch'),'win64'))

  if(~exist('./sc2_cam.dll','file'))
   copyfile('./x64/sc2_cam.dll','./');
  end 
  if(exist('grabfunc.c','file'))
   if(~exist('./sc2_cam.lib','file'))
    copyfile('./x64/sc2_cam.lib','./');
   end 
  end
  if(~exist('./sc2_cl_me4.dll','file'))
   if(exist('./x64/sc2_cl_me4.dll','file'))
    copyfile('./x64/sc2_cl_me4.dll','./');
   end 
  end 
  if(~exist('./sc2_cl_nat.dll','file'))
   if(exist('./x64/sc2_cl_nat.dll','file'))
    copyfile('./x64/sc2_cl_nat.dll','./');
   end 
  end 
  if(~exist('./sc2_cl_mtx.dll','file'))
   if(exist('./x64/sc2_cl_mtx.dll','file'))
    copyfile('./x64/sc2_cl_mtx.dll','./');
   end 
  end 

 else
  error('This platform is not supported');   
 end 

if(exist('grabfunc.c','file'))
 mex grabfunc.c -lSC2_Cam -L.\
end 


 