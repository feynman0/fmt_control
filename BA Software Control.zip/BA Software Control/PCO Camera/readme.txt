//-----------------------------------------------------------------//
// Name        | readme.txt                  | Type: ( ) source    //
//-------------------------------------------|       ( ) header    //
// Project     | Matlab edge mt2             |       (*) others    //
//-----------------------------------------------------------------//
// Platform    | INTEL PC                                          //
//-----------------------------------------------------------------//
// Environment | Matlab 2011                                       //
//-----------------------------------------------------------------//
// Purpose     | instructions for use                              //
//-----------------------------------------------------------------//
// Author      | MBL, PCO AG                                       //
//-----------------------------------------------------------------//
// Revision    | 0,0,00,02                                        //
//-----------------------------------------------------------------//
// Notes       |                                                   //
//             |                                                   //
//             |                                                   //
//             |                                                   //
//-----------------------------------------------------------------//
// (c) 2014-2016 PCO AG * Donaupark 11 *                           //
// D-93309      Kelheim / Germany * Phone: +49 (0)9441 / 2005-0 *  //
// Fax: +49 (0)9441 / 2005-20 * Email: info@pco.de                 //
//-----------------------------------------------------------------//


The Matlab edge project is a collection of example m-files and
additional header files.
Also the necessary dll-files are included.

With these files the setup of the camera can be done and
there are function to grab images to an Matlab imagestack
or to grab and display in a figure window. 

Only a subset of all possible camera settings is done in the examples.
For further setup see the pco.camera SDK description.

When working on a 64Bit-Window system a c-compiler must be installed 
to enable Matlab to use external dll's.
See also http://de.mathworks.com/support/compilers/current_release/



To run the example code copy and unzip the matlab archiv in a distinct install directory.

Then open Matlab and select the install directory.


call script 'setup_files'
 (which does the followin steps)
or
 Depending on your environment copy the dll files either from the w32 or the x64 subdirectory
 to the install directory.

call 'pco_camera_create_deffile'
which will create a pco_camera_def.txt file with header definitions


All m-files which begin with pco_camera include subfunctions,
which can be used in other files or also standalone

All m-files which begin with pco_edge are examples with different functionality
All files include helptext which can be shown with command
'help pco_edge_stack'

There are three example files described below

For a simple test call pco_camera_info.m m-file
'pco_camera_info();'
This should output some messages about camera type and camera revisions


Grab and display:

Single Grab
'pco_edge_single();'
parameters are (triggermode,exposure_time) 

'edge_single(0,5);'
Grab and display a single image with exposure time of 5ms.


Grab and display in a loop
'pco_edge_live_getima();'
'pco_edge_live_add();'
start camera, grab and display images in a loop
parameters are (looptime,triggermode)

pco_edge_live_add() does use SDK-functions PCO_AddBuffer and PCO_WaitforBuffer with 4 Buffers
pco_edge_live_getima() does use SDK-function PCO_GetImageEx with a single buffer


Grab to image stack:

'image_stack=pco_edge_stack();'
parameters are (imacount,triggermode,exposure_time)
pco_edge_stack() uses only Matlab-script code

image_stack is transposed before returned to workspace
returned image_stack can be displayed with one of the draw_images functions


All m-files use a common structure glvar.
When setting variables of this structure different behaviour of loading/unloading SDK library and
open/close of the camera could be accomplished.


All example code was tested with Matlab2011 64Bit Version.

When writing your own m-files it might happen that matlab does stop due to a syntax or other error.
Because then the camera is not closed correctly, the next run of the corrected m-file will fail.
To avoid this best practice is to run 'pco_camera_open_close();', which will return with error but does 
close the camera and unload the SC2_Cam-library.


VERSION HISTORY:
Version 0.0.0.2:
- use files from pco.camera SDK1.19
- correct errdisp for Matlab version 8.0.0


Version 0.0.0.1:
- first release
- use files from pco.camera SDK1.18
- converted from pco.edge + edge usb Version

KNOWN BUGS:
 none

