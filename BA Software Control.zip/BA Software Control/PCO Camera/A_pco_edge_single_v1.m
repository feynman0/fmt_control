function img = A_pco_edge_single_v1(triggermode,exposure_time)
clear; clf reset; clc;

glvar=struct('do_libunload',0,'do_close',0,'camera_open',0,'out_ptr',[]);

if(~exist('exposure_time','var'))
    exposure_time = 10;
end

if(~exist('triggermode','var'))
    triggermode = 0;
end

[err,glvar]=pco_camera_open_close(glvar);
pco_errdisp('pco_camera_setup',err);
disp(['camera_open should be 1 is ',int2str(glvar.camera_open)]);
if(err~=0)
    commandwindow;
    return;
end

out_ptr=glvar.out_ptr;

subfunc=pco_camera_subfunction();

subfunc.fh_stop_camera(out_ptr);

%do settings starting from a known state
subfunc.fh_reset_settings_to_default(out_ptr);

subfunc.fh_enable_timestamp(out_ptr,2);
subfunc.fh_set_exposure_times(out_ptr,exposure_time,2,0,2);
subfunc.fh_set_triggermode(out_ptr,triggermode);

errorCode = calllib('PCO_CAM_SDK', 'PCO_ArmCamera', out_ptr);
pco_errdisp('PCO_ArmCamera',errorCode);

%adjust transfer parameter if necessary
subfunc.fh_set_transferparameter(out_ptr);
subfunc.fh_get_triggermode(out_ptr);
subfunc.fh_show_frametime(out_ptr);

disp('get single image');
[err,ima,glvar]=pco_camera_stack(1,glvar);
if(err==0)
    img = ima;
    clear ima;
    img = imresize(img,[256 256]);
    set(gca,'LooseInset',get(gca,'TightInset'));
    %imshow(img);
    imwrite(img, 'C:\Users\Andrin\Documents\MATLAB\Images\phantom_8.png');
end

subfunc.fh_stop_camera(out_ptr);

if(glvar.camera_open==1)
    glvar.do_close=1;
    glvar.do_libunload=1;
    pco_camera_open_close(glvar);
end

clear glvar;
close()
end